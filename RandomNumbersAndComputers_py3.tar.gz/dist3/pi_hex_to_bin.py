def main():
    f = open("pi_hex_1b.txt","r")
    g = open("random_pi.dat","wb")

    f.read(2)

    c = []
    for i in range(1000000000):
        c.append(int(f.read(2),16))
    g.write(bytes(c))


main()

